console.log("Task 3 sample file");
